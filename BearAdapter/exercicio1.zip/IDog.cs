﻿namespace BearAdapter
{
    public interface IDog
    {
        void Bark();
        void Fetch(object objectToFetch);
    }
}
