﻿namespace BearAdapter
{
    public interface IWolf
    {
        void Howl();
        void Chase(object objectToChase);
        void Kill(object objectToKill);
    }
}
